package mx.ipn.cic.geo.currency_app

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.SeekBar
import android.widget.TextView
import com.google.gson.Gson
import mx.ipn.cic.geo.currency_app.databinding.ActivityMainBinding
import java.io.InputStreamReader
import java.net.URL
import javax.net.ssl.HttpsURLConnection

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Se coloca como comentario, cambio por usar viewbinding.
        // setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val viewMonedaBase: TextView = findViewById(R.id.textMonedaBase) as TextView

        val seek = findViewById<SeekBar>(R.id.slBarra)

        /*val minimo = 1
        val maximo = 50000
        val paso = 0.5

        seek.max = (maximo - minimo) / paso as Int*/

        seek?.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            @SuppressLint("SetTextI18n")
            override fun onProgressChanged(seek: SeekBar, p1: Int, fromUser: Boolean) {

                viewMonedaBase.text = "MXN: \$ $p1"

            }

            override fun onStartTrackingTouch(seek: SeekBar) {
                // write custom code for progress is started
            }

            override fun onStopTrackingTouch(seek: SeekBar) {
                // write custom code for progress is stopped
                val entradita = seek.progress
                getCurrencyData(entradita).start()
            }
        })

        // Invocar el método para equivalencia de monedas.
        //getCurrencyData().start()
    }




    private fun getCurrencyData(valor1: Int): Thread
    {
        return Thread {
            val url = URL("https://open.er-api.com/v6/latest/mxn")
            val connection = url.openConnection() as HttpsURLConnection

            Log.d("Resultado Petición: ", connection.responseCode.toString())

            if(connection.responseCode == 200) {
                val inputSystem = connection.inputStream
                val inputStreamReader = InputStreamReader(inputSystem, "UTF-8")
                val request = Gson().fromJson(inputStreamReader, Request::class.java)
                updateUI(request, valor1)
                inputStreamReader.close()
                inputSystem.close()
            }
            else {
                binding.textMonedaBase.text = "PROBLEMA DE CONEXIÓN"
            }
        }
    }

    private fun updateUI(request: Request, multiplicador: Int)
    {
        runOnUiThread {
            kotlin.run {
                val fechita: String = request.time_last_update_utc.dropLast(5)
                binding.textActualizacion.text = fechita
                binding.textMonedaEuro.text = String.format("EUR: € %.2f", request.rates.EUR * multiplicador)
                binding.textMonedaDolar.text = String.format("USD: \$ %.2f", request.rates.USD * multiplicador)
                binding.textMonedaLibra.text = String.format("GBP: £ %.2f", request.rates.GBP * multiplicador)
                binding.textMonedaAng.text = String.format("AOA: cor %.2f", request.rates.AOA * multiplicador)
                binding.textMonedaCan.text = String.format("CAD: Дин %.2f", request.rates.CAD * multiplicador)
                binding.textMonedaDen.text = String.format("DKK: \$ %.2f", request.rates.DKK * multiplicador)
                binding.textMonedaArg.text = String.format("ARS: G %.2f", request.rates.ARS * multiplicador)
                binding.textMonedaCol.text = String.format("COP: R\$ %.2f", request.rates.COP * multiplicador)
                binding.textMonedaBul.text = String.format("BGN: R\$ %.2f", request.rates.BGN * multiplicador)
            }
        }
    }

    private fun cambiaTexto(){

    }
}