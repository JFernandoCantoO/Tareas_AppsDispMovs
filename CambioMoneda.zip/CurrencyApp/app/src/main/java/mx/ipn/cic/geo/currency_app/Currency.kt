package mx.ipn.cic.geo.currency_app

class Currency {
    var EUR: Double = 0.0
    var USD: Double = 0.0
    var GBP: Double = 0.0
    var AOA: Double = 0.0 // Angola
    var CAD: Double = 0.0 // Canada
    var DKK: Double = 0.0 // Denmark
    var ARS: Double = 0.0 // Argentina
    var COP: Double = 0.0 // Colombia
    var BGN: Double = 0.0 // Bulgaria

}