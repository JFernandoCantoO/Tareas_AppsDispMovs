package com.example.firebase_conexion.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
//import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.firebase_conexion.MainAdapter
import com.example.firebase_conexion.viewmodel.MainViewModel
import com.example.firebase_conexion.R
import com.example.firebase_conexion.Usuario
import com.example.firebase_conexion.domain.data.network.Repositorio
import kotlinx.android.synthetic.main.activity_main.*

//import kotlinx.coroutines.flow.internal.NoOpContinuation.context
//import kotlin.coroutines.jvm.internal.CompletedContinuation.context

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: MainAdapter
    private val viewModel by lazy { ViewModelProviders.of(this)[MainViewModel::class.java] }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        adapter = MainAdapter(this)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        val dummyList:MutableList<Usuario> = mutableListOf<Usuario>()
        dummyList.add(Usuario("https://www.google.com/search?q=perritos&rlz=1C1UEAD_esMX1019MX1019&sxsrf=ALiCzsZ3MvqubMv-buUalGpnXceWHC2dzg:1669333410419&source=lnms&tbm=isch&sa=X&ved=2ahUKEwj69MHH_8f7AhXNJkQIHdwsAfUQ_AUoAXoECAEQAw&biw=1600&bih=732&dpr=1#imgrc=80biw95GGKfWZM",
            "Dato0", "Imagen de Prueba"))

        adapter.setListData(dummyList)
        adapter.notifyDataSetChanged()


    }





}