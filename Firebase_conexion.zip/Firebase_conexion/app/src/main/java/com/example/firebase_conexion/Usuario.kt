package com.example.firebase_conexion

data class Usuario(val imageURL:String? = "URL",
                    val nombre:String? = "NAME",
                    val descripcion:String? = "DESCRIPTION")
